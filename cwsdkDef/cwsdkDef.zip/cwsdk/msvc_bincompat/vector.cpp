#include "vector.h"

// Binary compatability for MS VC++ 11.0 / _MSC_VER=1700
namespace MSVCBinCompat {
};