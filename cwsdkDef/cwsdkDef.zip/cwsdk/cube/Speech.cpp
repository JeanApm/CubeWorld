#include "Speech.h"

namespace cube {
};