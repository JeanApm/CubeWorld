#pragma once

namespace plasma {
	template<int C, typename T>
	class Vector {
	public:
		T data[C];
	};
};