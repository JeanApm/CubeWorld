#pragma once

namespace plasma {
	template<typename T>
	class Matrix {
	public:
		T _m[16];
	};
};