#pragma once

#include <cstdint>
#include "Keyable.h"

namespace plasma {
	class Shape : Keyable {
	public:
		uint32_t field_44;
		uint32_t field_48;
		uint32_t field_4C;
		uint32_t field_50;
		uint32_t field_54;

		virtual void vf_dtor(uint8_t x) {};
		virtual void vf1();
		virtual void vf2();
		virtual void vf3();
		virtual void vf4();
		virtual void vf5();
		virtual void vf6();
		virtual void vf7();
		virtual void vf8();
		virtual void vf9();
		virtual void vf10();
		virtual void vf11();
		virtual void vf12();
		virtual void vf13();
		virtual void vf14();
		virtual void vf15();
		virtual void vf16();
		virtual void vf17();
		virtual void vf18();
	};
};