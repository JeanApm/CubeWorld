#pragma once

#include "./msvc_bincompat/string.h"
#include "./msvc_bincompat/wstring.h"
#include "./msvc_bincompat/map.h"
#include "./msvc_bincompat/vector.h"

